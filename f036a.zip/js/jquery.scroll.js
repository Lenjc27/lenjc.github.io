$(function() {
   var pagetop = $('#pagetop');
  //ボタンを隠す
   pagetop.css('bottom', '-80px');
   $(window).scroll(function () {
  //スクロールが100以上になったら
        if($(window).scrollTop() >= 100){
  //表示
            pagetop.stop().animate({bottom:'20px'},200);
      } else {
  //以下なら隠す
            pagetop.stop().animate({bottom:'-80px'},200);
      }
   });
    //スクロール
  $('a[href^=#]').click(function() {
    var href = $(this).attr("href");
    var target = $(href == "#" || href == "" ? 'html' : href);
    var position = target.offset().top;
    //500は速度
    $("html, body").animate({scrollTop:position}, 500, 'swing');
        return false;
  });
});
