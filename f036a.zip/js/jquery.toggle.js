$(function() {
  $('.main-menu').on('click', function() {
    $(this).next('ul').slideToggle();
    $(this).children('span').toggleClass('open');
    $('.sub-menu').not($(this).next('.sub-menu')).slideUp();
    $('.main-menu').children('span').not($(this).children('span')).removeClass('open');
  });
});
